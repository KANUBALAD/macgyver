# -*- coding: utf-8 -*-
class Position:
	def __init__(self, line, column):
		self.line = line
		self.column = column

	def __str__(self):
		"""renvoie via un print(objet) : la position (line: \n column:) du perso dans le terminal"""
		strToReturn = "line: " + str(self.line) + "\n"
		strToReturn = strToReturn + "column: " + str(self.column) + "\n"
		return strToReturn

	def __eq__(self, other):
		"""renvoie false (ou true si les positions comparées sont les mêmes)"""
		return (self.line == other.line) and (self.column == other.column)