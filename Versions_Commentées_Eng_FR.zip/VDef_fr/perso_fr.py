# -*- coding: utf-8 -*-
import position as Position
from labyManager import LabyManager
from constantes import *


class Perso:
	def __init__(self, pos, hasEther=False, hasTube=False, hasNeedle=False, alive=True):
		"""attributs d'instance : une position, des objets à récupérer, une vie perdable"""
		self.pos = pos
		self.alive = alive
		self.hasEther = hasEther
		self.hasTube = hasTube
		self.hasNeedle = hasNeedle



	def __str__(self):
		"""renvoie un "§ descriptif" sur l'état (attributs) du perso dans le terminal"""
		"""ps : méthode spéciale pour afficher l'objet avec print"""
		description = "Perso position:\n" + str(self.pos) + "\n"
		description += "alive: " + str(self.alive) + '\n'
		description += "has needle: " + str(self.hasNeedle) + '\n'
		description += "has ether: " + str(self.hasEther) + '\n'
		description += "has tube: " + str(self.hasTube) + '\n'
		return description


	def goLeft(self, labyManager):
		goingToPos = Position.Position(self.pos.line, self.pos.column - 1)
		"""sa position future, une column vers la gauche -1 (+1 pour droite, +1 sur la line pour descendre, -1 pour monter)"""
		self.willStepOnObject(goingToPos, labyManager)
		"""un test objet et vie cf. méthode willStep...ci-dessous"""
		if labyManager.charAtPosition(goingToPos) != "*" and self.pos.column > 0:
			"""si la position future n'est pas le mur et qu'il n'est pas déjà sur la 1ère colonne alors:"""
			labyManager.updatePersoPositionInLaby(self.pos, goingToPos)
			"""on update les éléments du laby, le 8 (i.e. mac) se déplace vers la gauche et l'ancien position devient vide"""
			self.pos = goingToPos
			"""la position = la nouvelle position, ce qui permet de repartir dans la boucle avec ce nouvel état de position"""
		else:
			pass
			"""rien ne ce passe, retour dans la boucle et attente de la nouvelle direction donnée"""
    	

	def goRight(self, labyManager):
		goingToPos = Position.Position(self.pos.line, self.pos.column + 1)
		self.willStepOnObject(goingToPos, labyManager)
		if labyManager.charAtPosition(goingToPos) != "*" and self.pos.column < len(labyManager.laby[self.pos.line]) - 1:
			"""si la position future n'est pas le mur et qu'il n'est pas déjà sur la dernière colonne de sa ligne alors:"""
			labyManager.updatePersoPositionInLaby(self.pos, goingToPos)
			"""on update les éléments du laby, le 8 (i.e. mac) se déplace vers la droite et l'ancien position devient vide"""
			self.pos = goingToPos
		else:
			pass
    	

	def goUp(self, labyManager):
		"""idem cf. goLeft for more explnantions"""
		goingToPos = Position.Position(self.pos.line - 1, self.pos.column)
		self.willStepOnObject(goingToPos, labyManager)
		if labyManager.charAtPosition(goingToPos) != "*" and self.pos.line > 0:
			labyManager.updatePersoPositionInLaby(self.pos, goingToPos)
			self.pos = goingToPos
		else:
			pass
    	

	def goDown(self, labyManager):
		"""idem cf. goLeft for more explanations"""
		goingToPos = Position.Position(self.pos.line + 1, self.pos.column)
		"""généré par le mouvement K_DOWN"""
		self.willStepOnObject(goingToPos, labyManager) #aucune action si goingToPos = * = un mur
		if labyManager.charAtPosition(goingToPos) != "*" and self.pos.line < len(labyManager.laby) - 1:
			labyManager.updatePersoPositionInLaby(self.pos, goingToPos)
			self.pos = goingToPos
		else:
			pass

	def willStepOnObject(self, pos, labyManager):
		"""si la prochaine position est un mur i.e. "*" aucun changement d'attibut à True. cqfd"""
		if labyManager.charAtPosition(pos) == 'N':
			"""si la prochaine position == N, alors l'attribut passe à True"""
			self.hasNeedle = True
		elif labyManager.charAtPosition(pos) == 'E':
			self.hasEther = True
		elif labyManager.charAtPosition(pos) == 'T':
			self.hasTube = True
		elif labyManager.charAtPosition(pos) == 'X':
			if not self.hasAllObjects():
				"""si Mac n'a pas tous les objets, le garde le tue => sortie du while du game_loop"""
				self.alive = False
	

	def hasAllObjects(self):
		"""renvoie False si un 3 des attributs d'instance est à False"""
		"""renvoie True si Mac possède (i.e. est passé) sur les 3 objets (tous à True)"""
		return self.hasNeedle and self.hasTube and self.hasEther


	
