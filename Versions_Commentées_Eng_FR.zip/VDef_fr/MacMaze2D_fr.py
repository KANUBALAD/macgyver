# -*- coding: utf-8 -*-
import pygame
import position as Position
import perso as Perso
from random import randint
from labyManager import LabyManager
from constantes import*

"""déclarés en dehors de def main() car utilisation dans d'autres méthodes"""
continuePlaying = True
gameEnded = False
win = False
pygame.init()
screen = pygame.display.set_mode((cote_fenetre, cote_fenetre))

def text_objects(text, font):
    textSurface = font.render(text, True, WHITE) 
    """texte et couleur de la fonte"""
    return textSurface, textSurface.get_rect() 
    """pour déclarer son emplacement ensuite"""


def message_display(text):
    """font = pygame.font.Font('freesansbold.ttf', 15)"""
    pygame.font.init() 
    """initialize (inside the methode) the font module"""
    font = pygame.font.Font('fonts/3270Medium.ttf', 15) 
    """creation d'une fonte"""
    TextSurf, TextRect = text_objects(text, font)
    """TextSurf, TextRect = font.render(text, True, WHITE),textSurface.get_rect()"""
    TextRect.center = ((cote_fenetre / 2),(cote_fenetre / 2))
    screen.blit(TextSurf, TextRect)
    pygame.display.update()

def confirm_dialog(text):
    screen.fill(BLACK)   
    message_display(text)  
    """message affiché, text en paramètre"""  
    pygame.display.update() 
    """update de tout l'écran en l'absence de paramètre"""
    isRunning = True 
    """boucle infinie même si quit or escape via false ci-dessous"""
    answer = False
    while isRunning:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                isRunning = False
            elif event.type == pygame.KEYDOWN:
                isRunning = False
                """Answer détermine le start() ou quit() ds handle_game_end()"""
                if event.key == pygame.K_y:
                    answer = True
    return answer 
    """1 funct° (inspite of 2 to manage 2 no) : yes as pivot value."""

def wait_for_key_pressed():
    """boucle infinie, sortie permise par quit or any keydown"""
    isRunning = True
    while isRunning:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                isRunning = False
            elif event.type == pygame.KEYDOWN:
                isRunning = False


def quit_game():
    screen.fill(BLACK)
    message_display("Thank you for playing Mac Maze. See you soon!")
    wait_for_key_pressed()
    screen.fill(BLACK)
    message_display("Press any key to quit.")
    wait_for_key_pressed()
    pygame.quit()


def game_loop():
    """global : les variables seront aussi comprises en dehors de la méthode"""
    global win
    global continuePlaying
    global gameEnded
    continuePlaying = True
    win = False
    """instance "lm" possède attributs et méthodes d'instance conférées par la classe"""
    lm = LabyManager() 
    lm.initializeGame()
    perso = Perso.Perso(lm.initPosition)
    """.txt remplacé par images, emplacement de 1*30 sur 15 emplacements/sprites"""
    lm.displayLaby(screen)
    """Sortie de boucle si perso sur exitPos°, en vie et avec volonté de jouer"""
    while not (perso.pos == lm.exitPosition) and perso.alive and continuePlaying:
        """Rechargement suite à déplacements .txt dc images sur emplacements"""
        lm.displayLaby(screen)
        """Titre et compteur (updaté via la boucle de déplacement) d'objets récupérés"""
        pygame.display.set_caption("MacGyver have: " + lm.nbInGameObjets() + "/3 objects. Use arrows to move")
        """Update (des (re)chargements images) dans le display pygame"""
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                """Quit génère Sortie de boucle avec volonté de quitter"""
                continuePlaying = False
                break
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT :
                    """commande de mouvement classique de perso, instance lm passée en paramètre"""
                    perso.goLeft(lm)
                    """méthode de déplacement en conséquence du mouvement"""
                elif event.key == pygame.K_RIGHT:
                    perso.goRight(lm)
                elif event.key == pygame.K_UP:
                    perso.goUp(lm)
                elif event.key == pygame.K_DOWN:
                    perso.goDown(lm)
                elif event.key == pygame.K_ESCAPE:
                    """Escape génère Sortie de boucle avec volonté de quitter"""
                    continuePlaying = False
                    break
        """Valeurs renvoyées si break ou si exitPos°, en vie et avc volonté de jouer"""
        """Sinon soit (exitPos° + en vie) soit (Mort suite à combat sans objets)"""
    win = perso.alive #and perso.hasAllObjects()
    gameEnded = True

def start_game():
    global gameEnded
    gameEnded = False
    while not gameEnded:
        """methode directionnelle qui, aussi, renvoie des valeurs de win et gameEnded"""
        game_loop()
    handle_game_end()


def handle_game_end():
    """Ont les valeurs de sortie de la game_loop() via le global"""
    global win
    global continuePlaying
    """Si volonté de stopper i.e. quit or escape pressed in game_loop"""
    if not continuePlaying:
        confirmed = confirm_dialog("Are you sure you want to quit? (y / n)")
        if confirmed:
            quit_game() #with Yes pressed (yes as "pivot value")
        else:
            start_game() #with quit or any keydown**
       
            """Sinon jouer = True, donc test de win (en vie donc avec les objets)"""     
    else:       
        if win:
            confirmed = confirm_dialog("Congratulations! You won! Play again? (y / n)")
            if confirmed:
                start_game() #with Yes pressed (yes as "pivot value")
            else:
                quit_game() #with quit or any keydown**
            
            """Sinon, perso.alive = False i.e. confrontation gardien perdue"""
        else: 
            confirmed = confirm_dialog("You are dead, try again? (y / n)")
            if confirmed:
                start_game()
            else:
                quit_game()

def main():
    start_game()


if __name__ == "__main__":
    main()
