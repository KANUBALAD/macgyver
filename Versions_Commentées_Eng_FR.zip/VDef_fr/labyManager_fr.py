# -*- coding: utf-8 -*-
from random import randint
import position as Position
import pygame
from constantes import*
import perso as Perso


class LabyManager:
	def __init__(self):
		self.laby = [] #Nécessaire car doit être connu de plusieurs méthodes d'instance (dans une logique de continuité).
		#self.positionList = [] (Non nécessaire en attribut car utilisé, en son sein par une seule et même méthode d'instance).
		self.initPosition = (0,0)
		self.exitPosition = (0,0)
		self.availableCases = [] 
		#self.gameObjetList = []
		

	@staticmethod
	def replace(inputStrinng, i, char):
	    outputString = inputStrinng[:i] + char + inputStrinng[i + 1:]
	    return outputString


	def loadLABY(self):
		"""pour le fichier ouvert, lire les lignes, fermer le fichier"""
		with open('./maps/laby03.txt') as file:
			"""nb: readlines() va ajouter, sur chaque ligne, un 16ième et dernier caractère : '\n' (=passage à la ligne dans le txt)"""
			self.laby = file.readlines()
			"""un item de cette liste est une ligne complète"""
		file.close()
		self.removeEndOfLineChar()

		
	def removeEndOfLineChar(self):
		"""pour chaque ligne du laby chargé de l'instance"""
		for line in self.laby:
			"""soit indexOfLastChar la dernière et 16ième position de la ligne numérotée 15 (i.e. 0...15 et len(line) = 16)"""
			indexOfLastChar = len(line) - 1
			if line[indexOfLastChar] == '\n':
				"""si ce 16ième et dernier caractère (en position n°15) égal '\n' (i.e. ligne suivante dans le txt chargé) alors:"""
				indexOfCurrentLine = self.laby.index(line)
				"""fonction index() : soit indexOfCurrentLine le n° de la ligne du laby sur laquelle on se situe"""
				line = self.replace(line, indexOfLastChar, '')
				"""soit cette ligne  = cette ligne avec l'implémentation du vide sur le dernier caractère"""
				self.laby[indexOfCurrentLine] = line
				"""insertion de cette ligne modifiée en lieu et place de l'ancienne ligne qui avait le \n"""


	def buildAvailPositionList(self):
		positionList = []
		for line in self.laby:
			for x in range(0, len(line)):
				"""on parcours un range (i, j) = [i,...,j-1], ici len(line)=15 soit range = [0,...14] soit 15 positions possibles suite au retrait du \n : OK"""
				if line[x] == " ":
					"""si la position (i.e. n° colonne) parcourue sur la ligne est du vide"""
					indexOfCurrentLine = self.laby.index(line)
					"""soit indexOfCurrentLine le n° de la ligne du laby sur laquelle on se situe"""
					positionList.append(Position.Position(indexOfCurrentLine, x)) #rem. hors contexte** : un .append d'1 instance sur 1'attr. de classe update ce dernier "chez" ttes les instances.
					"""on ajoute à positionList : TOUTES les positions parcourues (n°ligne,n°colonne) via un appel du module Position puis de la classe Position"""
		return positionList #positionList une var. (liste d'instances "position") de la méthode d'instance, non un attribut de classe, ni une instance d'où le hors contexte** de la rem..

		
	def generateInGameObjets(self):
		for x in range(1, 4):
			"""range(1, 4) = [1, 2, 3] sinon range(0, 4) = [0, 1, 2, 3]"""
			availableCasesCount = len(self.availableCases)
			"""aCasesCount = len(availabCases (attr. d'instance)) = len("positionList") retourné par buildAvailPositionList(), cf. initializeGame()"""
			index = (randint(0, availableCasesCount))
			"""pris au hasard entre la 1ère et la dernière possibilité de positions"""
			if index < availableCasesCount:
				"""si 15 aCC index 15 sera out of range ==> range(0,15) = [0,...14]"""
				position = self.availableCases[index]
				"""Ccl° : position = une des positions prise au hasard dans les positions d'availableCases"""
				if x == 1:
					"""si c'est le 1er passage i.e 1er objet créé = N """
					self.laby[position.line] = self.replace(self.laby[position.line], position.column, "N") #N=NEEDLE
					""" la ligne (attribut) de la positon = la ligne de la position où on remplace le vide par un "N" sur la colonne (attr) de la position"""
				elif x == 2:
					self.laby[position.line] = self.replace(self.laby[position.line], position.column, "E") #E=ETHER
					"""2ième passage : idem car position est une instance de la classe Position tous commes les autres positions d'availableCases"""
				else:
					self.laby[position.line] = self.replace(self.laby[position.line], position.column, "T") #T=TUBE
				self.availableCases.pop(index)
				"""la position utilisée est retirée des positions et la boucle reprend (évite de mettre N et E à la même position"""


	def findExitPosition(self):
		for line in self.laby:
			for x in line:
				"""le X c'est le guardien"""
				if x == 'X':
					return Position.Position(self.laby.index(line), line.index(x))
					"""exitPosition devient ici une instance de position (column, line)"""
					

	def findInitPosition(self):
		for line in self.laby:
			for x in line:
				if x == '8':
					"""le 8 c'est Macgyver"""
					return Position.Position(self.laby.index(line), line.index(x))

		
		
	def initializeGame(self):
		self.loadLABY() 
		"""Chargement de l'attribut laby de l'instance du game_loop"""
		self.availableCases = self.buildAvailPositionList() 
		"""détection des positions libres du laby"""
		self.generateInGameObjets() 
		"""créatio aléatoires d'objets sur les positions libres du laby"""
		self.initPosition = self.findInitPosition()
		"""détermination de la position de départ et de celle de sortie"""
		self.exitPosition = self.findExitPosition()



	
	def displayLaby(self, shadow):
		wall = pygame.image.load('./images/wallm.png').convert_alpha()
		"""chargement de l'image wall"""
		
		mac = pygame.image.load('./images/macgyver1.png').convert()
		mac_b = pygame.transform.scale(mac, (30, 30))
		"""ajustement de la taille de l'image de mac chargée"""

		needle = pygame.image.load('./images/needle1.png').convert_alpha()
		needle_b = pygame.transform.scale(needle, (30, 30))

		ether = pygame.image.load('./images/ether.png').convert_alpha()
		ether_b = pygame.transform.scale(ether, (30, 30))

		tube = pygame.image.load('./images/tube.png').convert_alpha()
		"""_alpha() rend le fond de l'image transparent"""
		tube_b = pygame.transform.scale(tube, (30, 30))

		guard = pygame.image.load('./images/guard.png').convert_alpha()
	
		space = pygame.image.load('./images/space.png').convert_alpha()
		
		num_line = 0
		for line in self.laby:
			num_column = 0
			for sprite in line:
				x = num_column * taille_sprite
				y = num_line * taille_sprite
				if sprite == '*':
					shadow.blit(wall,(x,y))
					"""les * sont remplacés par l'image wall, les coordonnées de * sont modifiés"""
				elif sprite == "N":
					shadow.blit(needle_b,(x,y))
					"""(1,1) devient (30,30) par exemple et ainsi de suite (passage à l'échelle global)"""
				elif sprite == "T":
					shadow.blit(tube_b,(x,y))
				elif sprite == "E":
					shadow.blit(ether_b,(x,y))
				elif sprite == "8":
					shadow.blit(mac_b,(x,y))
				elif sprite == "X":
					shadow.blit(guard,(x,y))
				elif sprite == " ":
					shadow.blit(space,(x,y))
				num_column += 1
				"""colonne suivante sur la ligne parcourue"""
			num_line += 1
			"""une fois la ligne parcourue, on passe à la ligne suivante"""


	def updatePersoPositionInLaby(self, oldPos, newPosition):
		"""sur l'ancienne ligne du perso (8 i.e. mac), on met du vide au niveau de la colonne de la position"""
		self.laby[oldPos.line] = self.replace(self.laby[oldPos.line], oldPos.column, " ")
		"""sur la nouvelle ligne du perso ("", objet ou gardien), on met le 8 (i.e.) mac, au niv. de la col. de la position"""
		self.laby[newPosition.line] = self.replace(self.laby[newPosition.line], newPosition.column, "8")

	
	def nbInGameObjets(self):
		"""appelé dans le caption (cf. game_loop() : titre, compteur et mode de direction)"""
		gameObjetList = []
		for line in self.laby:
			for i in range(0, len(line)):
				if line[i] != "*" and line[i] != "X" and line[i] !=" " and line[i] != "8":
					"""pour chaque colonne de chaque ligne si caractère = E, N ou T alors"""
					indexOfCurrentLine = self.laby.index(line)
					gameObjetList.append(Position.Position(indexOfCurrentLine, i))
					"""on ajoute cette position à la liste de positions d'objet présents dans le laby"""
		return str(3-len(gameObjetList))
		"""on affiche (3-le nb d'objets) dans le titre du laby (i.e. dc 2 si un objet ramassés et 2 objets restants)"""

		
	def charAtPosition(self, pos):
		"""renvoie la position (line, column) dans le laby"""
		return self.laby[pos.line][pos.column]
	
		
	def message_display(self, text, shadow):
		"""Def non usité. ps : renverrai un message dans l'écran pygame"""
		myfont = pygame.font.SysFont("Comic Sans MS", 30)
		label = myfont.render(text, 1, (0, 255, 0))
		shadow.blit(label, (50, 215))
		"""position du message sur l'écran"""


	

