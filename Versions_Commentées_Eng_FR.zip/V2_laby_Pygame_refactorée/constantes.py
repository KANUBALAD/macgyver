"""Constantes du jeu de Labyrinthe Donkey Kong"""

#Paramètres de la fenêtre
nombre_sprite_cote = 15
taille_sprite = 30
cote_fenetre = nombre_sprite_cote * taille_sprite

#Personnalisation de la fenêtre
#titre_fenetre = "MacGyver Maze"

#Listes des images du jeu
#picture_ether = "ether.png"
#picture_needle = "needle.png"
#picture_tube = "tube.png"
