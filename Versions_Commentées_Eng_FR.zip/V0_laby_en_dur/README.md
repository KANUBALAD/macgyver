# RescueMac
Python, PyGame, Labyrinth
